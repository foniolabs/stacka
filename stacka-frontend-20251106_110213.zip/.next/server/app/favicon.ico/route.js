var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__e7d3f52d._.js")
R.c("server/chunks/5aff7_stacka__next-internal_server_app_favicon_ico_route_actions_5961e69e.js")
R.m(94936)
module.exports=R.m(94936).exports
