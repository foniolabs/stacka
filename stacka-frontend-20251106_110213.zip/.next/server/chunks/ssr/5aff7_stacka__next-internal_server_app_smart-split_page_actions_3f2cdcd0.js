module.exports=[57819,(a,b,c)=>{}];

//# sourceMappingURL=5aff7_stacka__next-internal_server_app_smart-split_page_actions_3f2cdcd0.js.map