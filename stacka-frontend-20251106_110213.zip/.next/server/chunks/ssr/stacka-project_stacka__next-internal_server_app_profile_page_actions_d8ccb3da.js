module.exports=[28640,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app_profile_page_actions_d8ccb3da.js.map