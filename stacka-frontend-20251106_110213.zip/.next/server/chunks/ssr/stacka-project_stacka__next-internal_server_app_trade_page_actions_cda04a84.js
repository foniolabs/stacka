module.exports=[30732,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app_trade_page_actions_cda04a84.js.map