module.exports=[20808,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app_dashboard_page_actions_0408e2a7.js.map