module.exports=[36051,(a,b,c)=>{}];

//# sourceMappingURL=5aff7_stacka__next-internal_server_app_stocks_nigerian_page_actions_4a0c5647.js.map