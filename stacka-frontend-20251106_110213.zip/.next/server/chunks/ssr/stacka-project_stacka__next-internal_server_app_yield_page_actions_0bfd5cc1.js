module.exports=[75930,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app_yield_page_actions_0bfd5cc1.js.map