module.exports=[49046,(a,b,c)=>{}];

//# sourceMappingURL=5aff7_stacka__next-internal_server_app_stocks_%5Bsymbol%5D_page_actions_62e76282.js.map