module.exports=[1708,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app__not-found_page_actions_c4779ddd.js.map