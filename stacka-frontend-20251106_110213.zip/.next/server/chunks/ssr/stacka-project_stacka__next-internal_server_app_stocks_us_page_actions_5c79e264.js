module.exports=[23026,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app_stocks_us_page_actions_5c79e264.js.map