module.exports=[3807,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},81230,a=>{"use strict";let b={src:a.i(3807).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=stacka-project_stacka_app_a39d5cde._.js.map