module.exports=[33796,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app_wallet_page_actions_23f36a0f.js.map