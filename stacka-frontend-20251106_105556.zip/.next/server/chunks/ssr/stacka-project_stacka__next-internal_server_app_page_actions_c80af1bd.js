module.exports=[80291,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app_page_actions_c80af1bd.js.map