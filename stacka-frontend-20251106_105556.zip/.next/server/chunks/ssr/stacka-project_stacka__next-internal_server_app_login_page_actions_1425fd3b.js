module.exports=[11316,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app_login_page_actions_1425fd3b.js.map