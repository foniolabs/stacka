module.exports=[17199,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app_portfolio_page_actions_77466ebc.js.map