module.exports=[68246,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app_signup_page_actions_eb236359.js.map