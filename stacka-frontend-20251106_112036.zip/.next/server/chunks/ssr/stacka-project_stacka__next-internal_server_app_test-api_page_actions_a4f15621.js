module.exports=[31825,(a,b,c)=>{}];

//# sourceMappingURL=stacka-project_stacka__next-internal_server_app_test-api_page_actions_a4f15621.js.map