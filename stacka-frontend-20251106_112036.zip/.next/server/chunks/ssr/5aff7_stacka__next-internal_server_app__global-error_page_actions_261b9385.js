module.exports=[70129,(a,b,c)=>{}];

//# sourceMappingURL=5aff7_stacka__next-internal_server_app__global-error_page_actions_261b9385.js.map