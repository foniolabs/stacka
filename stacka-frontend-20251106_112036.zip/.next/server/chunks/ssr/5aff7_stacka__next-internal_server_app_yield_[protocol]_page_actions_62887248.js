module.exports=[74251,(a,b,c)=>{}];

//# sourceMappingURL=5aff7_stacka__next-internal_server_app_yield_%5Bprotocol%5D_page_actions_62887248.js.map